perl dag.pl data/go.obo data/dag_BPO_ancestor.txt data/dag_BPO_descendant.txt BPO
perl dag.pl data/go.obo data/dag_CCO_ancestor.txt data/dag_CCO_descendant.txt CCO
perl dag.pl data/go.obo data/dag_MFO_ancestor.txt data/dag_MFO_descendant.txt MFO
